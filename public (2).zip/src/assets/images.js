import profileImg from './profileImg.png'
import emblem from './emblem.png'
import wodc from './wodc.png'
import project from './project.svg'


export const images = {
    profileImage:profileImg,
    emblem:emblem,
    wodc:wodc,
    project:project
}
